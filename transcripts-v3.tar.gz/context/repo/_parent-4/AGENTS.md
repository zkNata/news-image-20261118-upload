# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Autonomous development operating rules (set 2026-11-03, at user request)

- Work PLAN → EXECUTE → AUDIT → REPAIR → TEST → DOCUMENT → OPTIMIZE on every significant task. Never call a task complete until its output is verified (file exists, duration/size checked, frame checked for video, voice file checked for audio).
- Autonomous work is limited to reversible, documented steps. Sensitive or irreversible actions still need per-task user approval: no outward messages/DMs, no fund movement, no Binance disconnect, no deleting user data, no new recurring schedule without a named schedule approval.
- Never claim an improvement without measurable evidence (file, duration, check result, frame, or user confirmation). If a tool cannot guarantee something (e.g. phoneme-perfect lip-sync), say so plainly instead of claiming it.
- Keep every delivered version under a new filename; never overwrite a previous final video/audio so a bad remake can be rolled back.

## Verified lessons, 2026-11-03

- Voice must match the character before a full video is built. Default TTS voice was masculine and sounded like an adult man for Nori, a cute mascot, and the user rejected it twice. Fix: offer short voice samples first, let the user pick, then build the full voiceover with that voice. Nori's chosen voice is a bubbly voice pitch-shifted up about 25% with tempo preserved.
- Replacing clip audio with TTS breaks lip-sync. Clips are generated as speaking animations, then audio is replaced, so mouth movement is general, not phoneme-accurate. Fix: prompt speaking animation, use clear pauses, and disclose the limit; do not claim perfect sync.
- Video generators add unintended text claims. One CTA clip added "DISKON 50%" and another clip showed a wrong battery capacity text. Fix: check a frame at ~5s of every clip, discard/replace the offending clip, and use a no-text prompt for the CTA scene.
- Script version control matters. An early script said about 5 months in a wall clock; the final script says about 4 months and adds "with suitable size/spec" and "worth owning". Fix: treat the final script as the single source for voiceover, video, and caption; warn against posting old versions alongside the final one.
- Trim video to audio, not the other way round. A 42.77s voiceover with five 10s clips was trimmed to ~8.55s per clip so the closing CTA was not cut off; a 51.38s voiceover was matched by slowing the 50s video about 2.8%.
- Binance session checks are evidence, not guarantees. A read-only status/settings check on 2026-11-03 moved the 48h deadline to exactly check time + 48h, but the agent cannot guarantee Binance will always count it the same way. Fix: report the exact deadline returned, and tell the user their own app activity is the safest way to keep the session alive.

## Verified lessons, 2026-11-07

- Cron run record `started_at_utc` is NOT reliable for when a scheduled run actually started: on 2026-11-07 it showed ~04:02 WIB while the run's first worker (Zakki login agent) was created 01:00:10 WIB and finished 01:00:37 WIB — the run had started on time at 01:00. Fix: verify run start from the run's first subagent/worker timestamps, never from the cron run record alone, before telling the user a run started late.

## Verified lessons, 2026-11-17

- Bugcrowd triage closed 5 of 6 submissions on 16 Nov 2026 for $0, citing "theoretical, no valid PoC" and "potentially AI-generated" (OpenSea S1/SD-C5, Fireblocks CMP/presigning, OpenAI E-1); only Fireblocks heap stayed open as Unresolved + Duplicate. Lesson, set as a standing user rule: ALL bug bounty report data MUST be built with the available skills — `human-grade-bug-bounty-report-engineering` + `human-grade-bug-report-editor` for drafting, `bug-submission-readiness-and-peer-review` as the pre-submit gate (runnable PoC verified + multi-model peer review), `bounty_program_eligibility_gate` before audit and before submit, plus the relevant auditor skills for the research. No manual drafts outside these skills, no submit without a runnable PoC passing the readiness gate. Recorded in MEMORY.md and the shared index `~/workspace/bug-bounty-web3/INDEX-DIKERJAKAN.md` so every chat follows it.

## Performance Refresh protocol (always-on, set 2026-11-06 at user request)

- Speed is a first-class goal: shortest correct path, every token/tool call/step costs. Consistency over perfection — a slightly simpler fast answer beats a perfect slow one.
- Self-refresh is mandatory and silent: when reasoning gets long/repetitive, context bloats, or answers turn verbose, condense the current goal + key facts into a short working state, drop irrelevant history, pick the single most important next action, reset to short imperative low-token style, and continue without announcing it.
- Tool discipline: parallel calls where possible, no "just in case" calls, take only what's needed from a result then drop the rest, never re-read the same big file/output in one turn.
- Output default: brief, short paragraphs/bullets, don't repeat the question or earlier answers; expand only when the user explicitly asks for detail. Don't ask for confirmation on steps that are already clear.
- When the user says "refresh" / "reset" / similar: brief ack, short state summary (goal + key facts only), confirm ready, then wait or continue the running task.
